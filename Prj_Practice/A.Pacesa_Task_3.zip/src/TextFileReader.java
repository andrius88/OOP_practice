import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;



public class TextFileReader {

	List<Dish> dishList1 = new ArrayList<Dish>();
	List<Dish> dishList2 = new ArrayList<Dish>();
	List<Dish> dishList3 = new ArrayList<Dish>();
	List<Dish> dishList4 = new ArrayList<Dish>();
	List<DishCategory> mainList = new ArrayList<DishCategory>();

	
	public void readDishFile(){
		
		int id, catId;
		String readLine = "", dishName, dishDescription, pictureFileName;
		float dishPrice;
		
		try {
	        File f = new File("patieklai.txt");
	        BufferedReader b = new BufferedReader(new FileReader(f));
		
	        System.out.println("Reading file 'patieklai.txt' using Buffered Reader");
	
	        while ((readLine = b.readLine()) != null) {
	            
	            id = (Integer.parseInt(readLine));
	            catId = (Integer.parseInt(b.readLine()));
	            dishName = b.readLine();
	            dishPrice = (Float.parseFloat(b.readLine()));
	            dishDescription = b.readLine();
	            pictureFileName = b.readLine();
	            
	            makeDishList(id, catId, dishName, dishPrice, dishDescription, pictureFileName);
	            
	        	//System.out.println(readLine);
	        }
	
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	
	public void makeDishList(int id, int catId, String  dishName, float dishPrice, String  dishDescription, String pictureFileName){
		
		Dish anyDish = new Dish();
		anyDish.setId(id);
		anyDish.setCatId(catId);
		anyDish.setDishName(dishName);
		anyDish.setDishPrice(dishPrice);
		anyDish.setDishDescription(dishDescription);
		anyDish.setPictureFileName(pictureFileName);
		
		switch(catId) {
		  case 1:
			dishList1.add(anyDish);
		    break;
		  case 2:
			dishList2.add(anyDish);
		    break;
		  case 3:
			dishList3.add(anyDish);
			break;
		  case 4:
			dishList4.add(anyDish);
			break;
		}
	}
	
	
	
	public List<DishCategory> readMainList(){
		String readLine, categoryName;
		int catId;
		
		try {
	        File f = new File("kategorijos.txt");
	        BufferedReader b = new BufferedReader(new FileReader(f));
		
	        System.out.println("Reading file 'kategorijos.txt' using Buffered Reader");
	
	        while ((readLine = b.readLine()) != null) {
	            
	            catId = (Integer.parseInt(readLine));
	            categoryName = b.readLine();
	            
	            DishCategory dishCat = new DishCategory();
	    		dishCat.setCategoryID(catId);
	    		dishCat.setCategoryName(categoryName);

		    	switch(catId) {
		  		  case 1:
		  			dishCat.dishList = this.dishList1;
		  		    break;
		  		  case 2:
		  			dishCat.dishList = this.dishList2;
		  		    break;
		  		  case 3:
		  			dishCat.dishList = this.dishList3;
		  			break;
		  		  case 4:
		  			dishCat.dishList = this.dishList4;
		  			break;
		  		}	
	    		mainList.add(dishCat);
	            
	        	//System.out.println(readLine);
	        }
	
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
		return mainList;
	}
	
	/*public List<DishCategory> makeMainList(){				// hardcoded mainList
		DishCategory dishCat1 = new DishCategory();
		dishCat1.setCategoryID(1);
		dishCat1.setCategoryName("Picos");
		DishCategory dishCat2 = new DishCategory();
		dishCat2.setCategoryID(2);
		dishCat2.setCategoryName("Kebabai");
		DishCategory dishCat3 = new DishCategory();
		dishCat3.setCategoryID(3);
		dishCat3.setCategoryName("Mėsaianiai");
		DishCategory dishCat4 = new DishCategory();
		dishCat4.setCategoryID(4);
		dishCat4.setCategoryName("Kiti patieklai ir gėrimai");
		
		dishCat1.dishList = this.dishList1;
		dishCat2.dishList = this.dishList2;
		dishCat3.dishList = this.dishList3;
		dishCat4.dishList = this.dishList4;
		
		mainList.add(dishCat1);
		mainList.add(dishCat2);
		mainList.add(dishCat3);
		mainList.add(dishCat4);
		
		return mainList;
	}*/

}
